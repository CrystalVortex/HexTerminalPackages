import os

def install(pkg):
    os.system(f"npm install {pkg}")

def exec(cmd):
    os.system(f"npm {cmd}")